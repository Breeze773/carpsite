var lang = window.drupal_adsense_cse_lang;
(function() {
var f = document.getElementById('cse-search-box');
if (!f) {
f = document.getElementById('searchbox_demo');
}
if (f && f.as_q) {
var q = f.as_q;
var n = navigator;
var l = location;
var su = function (n, v, l) {
if (!encodeURIComponent || !decodeURI) {
return;
}
var u = document.createElement('input');
var regexp = new RegExp('(?:[?&]' + n + '=)([^&#]*)');
var existing = regexp.exec(v);
if (existing) {
v = decodeURI(existing[1]);
}
var delimIndex = v.indexOf('://');
if (delimIndex >= 0) {
v = v.substring(delimIndex + '://'.length, v.length);
}
u.name = n;
var v_sub = v.substring(0, l);
while (encodeURIComponent(v_sub).length > l) {
v_sub = v_sub.substring(0, v_sub.length - 1);
}
u.value = v_sub;
u.type = 'hidden';
f.appendChild(u);
};
var append = false;
if (n.appName == 'Microsoft Internet Explorer') {
var s = f.parentNode.childNodes;
for (var i = 0; i < s.length; i++) {
        if (s[i].nodeName == 'SCRIPT' &&
            s[i].attributes['src'] &&
            s[i].attributes['src'].nodeValue == unescape('http:\x2F\x2Fwww.google.com\x2Fcoop\x2Fcse\x2Fbrand?form=cse-search-box\x26amp\x3Blang=' + lang)) {
          append = true;
          break;
        }
      }
    } else {
      append = true;
    }
    if (append) {
      
      su('siteurl', document.location.toString(), 250);
      su('ref', document.referrer, 750);
    }

    
    if (n.platform == 'Win32') {
      q.style.cssText = 'border: 1px solid #7e9db9; padding: 2px;';
    }

    
    if (window.history.navigationMode) {
      window.history.navigationMode = 'compatible';
    }

    var b = function() {
      if (q.value == '') {
        q.style.background = '#FFFFFF url(http:\x2F\x2Fwww.google.com\x2Fcse\x2Fintl\x2F' + lang + '\x2Fimages\x2Fgoogle_custom_search_watermark.gif) left no-repeat';
      }
    };

    var f = function() {
      q.style.background = '#ffffff';
    };

    q.onfocus = f;
    q.onblur = b;

    
    if (!/[&?]q=[^&]/.test(l.search)) {
      b();
    }
  }
})();
