Installation
------------

Use the normal module process.

Settings
--------

Go to Admin >> Site configuration >> Site documentation settings.
Choose which options you want to use.
Go to Admin >> Site building >> Site documentation to run it according to the settings.

Hints
-----

This module can use a LOT of resources; try it on your test site first.

This module can produce a LOT of output, especially if you use all the settings. You might be better off running it in smaller increments at first until you've located all the surprises that you will very likely find. For example, try the "basic" and "blocks" sections at first.  Then move on to the taxonomy sections. Then try all of the node sections.