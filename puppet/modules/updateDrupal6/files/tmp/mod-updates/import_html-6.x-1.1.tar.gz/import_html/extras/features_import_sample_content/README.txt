Import HTML - Import content from source files as a feature
==========
@author dman dan@coders.co.nz
@version 2011


Demonstrates a way to pre-populate a site from deployed content HTML.

HTML folder may be deployed along with this feature, or referred to in other paths or even URLs.