
THIS MODULE INTENTIONALLY LEFT BLANK.

NOTICE: video_cck has been replaced by emvideo. If you follow the upgrade instructions properly,
i.e., you disable your modules in d5 before upgrading to d6, you should have no problems.
